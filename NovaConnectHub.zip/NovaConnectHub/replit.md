# Novalink Service

## Overview

Novalink Service is a professional B2B service platform designed to connect businesses with their customers through digital solutions. The application is a marketing and lead generation website for a digital services company offering sales funnels, automation, digital catalogs, and web development services. Built as a modern full-stack web application, it features a public-facing marketing site with service showcases, benefits sections, and a contact form, plus an administrative dashboard for managing incoming leads.

The application uses a monorepo structure with a React frontend and Express backend, designed to present professional service offerings and capture qualified leads through a streamlined conversion funnel.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- React 18 with TypeScript for type-safe component development
- Vite as the build tool and development server
- Wouter for lightweight client-side routing
- TanStack Query (React Query) for server state management and data fetching
- React Hook Form with Zod validation for form handling
- Tailwind CSS for utility-first styling
- shadcn/ui component library (New York variant) for consistent, accessible UI components

**Design System:**
- Custom design guidelines based on professional B2B references (Linear, Stripe, Vercel)
- Inter font family for typography across headings and body text
- Comprehensive spacing scale using Tailwind units
- Custom CSS variables for theme colors supporting light/dark modes
- Hover and active state utilities (`hover-elevate`, `active-elevate-2`) for interactive feedback

**Component Organization:**
- Page components in `client/src/pages/` (Home, Admin, NotFound)
- Reusable UI components in `client/src/components/` (Navbar, HeroSection, ServicesSection, BenefitsSection, ContactSection, Footer)
- shadcn/ui primitives in `client/src/components/ui/`
- Example components for development reference in `client/src/components/examples/`

**Routing Strategy:**
- `/` - Public marketing homepage with service showcase and contact form
- `/admin` - Administrative dashboard for viewing and managing contact submissions
- Fallback 404 page for unmatched routes

**State Management:**
- Server state managed via TanStack Query with custom query client configuration
- Form state handled by React Hook Form with Zod schema validation
- Local UI state using React hooks (useState, useEffect)
- Toast notifications for user feedback on form submissions and admin actions

### Backend Architecture

**Technology Stack:**
- Express.js server with TypeScript
- Custom Vite integration for serving the SPA in development and production
- In-memory storage implementation with interface for future database migration

**API Structure:**
- RESTful endpoints under `/api` prefix
- Contact management endpoints:
  - `POST /api/contacts` - Create new contact submission
  - `GET /api/contacts` - Retrieve all contacts
  - `GET /api/contacts/:id` - Retrieve single contact
  - `PATCH /api/contacts/:id` - Update contact
  - `DELETE /api/contacts/:id` - Delete contact

**Data Validation:**
- Shared Zod schemas between client and server (`shared/schema.ts`)
- Runtime validation on all API endpoints
- Type-safe data models using TypeScript inference from Zod schemas

**Error Handling:**
- Centralized error responses with appropriate HTTP status codes
- Request/response logging middleware for API routes
- JSON error responses with descriptive messages

**Storage Layer:**
- Interface-based storage abstraction (`IStorage`) for future extensibility
- Current implementation uses in-memory Map-based storage (`MemStorage`)
- UUID generation for entity identifiers
- Prepared for migration to PostgreSQL via Drizzle ORM (schema defined but not actively used)

### Data Layer

**Database Schema (Drizzle ORM - Prepared but not active):**
- `users` table with username/password fields for future authentication
- `contacts` table storing lead information:
  - Personal details (name, email, phone)
  - Company information
  - Service type and budget
  - Message content
  - Timestamp tracking

**Data Models:**
- Shared TypeScript types generated from Zod schemas
- Insert types (without auto-generated fields) for creating new records
- Full entity types for reading/updating records

**PDF Generation:**
- Client-side contract generation using jsPDF
- Dynamic content based on contact and service information
- Downloadable service agreements for admin use

### Authentication & Authorization

**Current State:**
- No authentication implemented (admin page is publicly accessible)
- User schema defined in database for future auth implementation

**Future Considerations:**
- Ready for session-based authentication (connect-pg-simple dependency present)
- Planned username/password authentication for admin access

## External Dependencies

### Core Framework Dependencies
- **React & React DOM** (v18+) - UI library
- **Express** - Backend web framework
- **Vite** - Build tool and development server
- **TypeScript** - Type system
- **Drizzle ORM** - Database ORM (configured for PostgreSQL via Neon)

### UI Component Libraries
- **Radix UI** - Headless component primitives (accordion, dialog, dropdown, select, tabs, toast, etc.)
- **shadcn/ui** - Pre-built accessible components using Radix UI
- **Lucide React** - Icon library
- **Tailwind CSS** - Utility-first CSS framework

### Form & Validation
- **React Hook Form** - Form state management
- **Zod** - Schema validation
- **@hookform/resolvers** - React Hook Form + Zod integration

### Data Fetching & State
- **TanStack Query** (React Query) - Server state management
- **wouter** - Lightweight client-side routing

### Database & Storage
- **@neondatabase/serverless** - PostgreSQL serverless driver (configured but storage not active)
- **Drizzle Kit** - Database migrations and schema management
- **connect-pg-simple** - PostgreSQL session store (for future auth)

### Utilities
- **date-fns** - Date manipulation and formatting
- **jsPDF** - PDF generation for contracts
- **class-variance-authority** - CSS variant utilities
- **clsx & tailwind-merge** - Conditional className utilities

### Development Tools
- **tsx** - TypeScript execution for development
- **esbuild** - Production backend bundling
- **@replit/vite-plugin-runtime-error-modal** - Development error overlay
- **@replit/vite-plugin-cartographer** - Replit-specific development features

### Build Configuration
- **PostCSS** with Autoprefixer - CSS processing
- **Tailwind CSS** - Configured with custom theme and design tokens
- **Path aliases** - `@/` for client src, `@shared/` for shared code, `@assets/` for attached assets

### Hosting Requirements
- Node.js runtime environment
- Environment variable `DATABASE_URL` (for future PostgreSQL connection)
- Static file serving capability
- Support for SPA routing (fallback to index.html)