# Novalink Design Guidelines

## Design Approach
**Selected Approach**: Reference-Based (Professional B2B Service Platform)

**Primary References**: Linear (clean typography, modern layouts), Stripe (professional credibility), Vercel (technical sophistication)

**Design Principles**:
- Professional credibility above all - build immediate trust
- Clear service differentiation and value proposition
- Streamlined conversion path to contact form
- Balance sophistication with approachability

## Typography System

**Font Stack**: 
- Primary: Inter (headings, UI elements)
- Secondary: Inter (body text, forms)

**Hierarchy**:
- Hero Headline: text-5xl lg:text-7xl font-bold
- Section Headers: text-3xl lg:text-5xl font-semibold
- Service Titles: text-2xl lg:text-3xl font-semibold
- Body Large: text-lg lg:text-xl
- Body Standard: text-base
- Caption/Meta: text-sm

## Layout System

**Spacing Scale**: Use Tailwind units of 4, 6, 8, 12, 16, 20, 24
- Component padding: p-6 to p-8
- Section vertical spacing: py-16 lg:py-24
- Container max-width: max-w-7xl
- Content max-width: max-w-4xl (for text-heavy sections)

**Grid Strategy**:
- Services grid: grid-cols-1 md:grid-cols-2 lg:grid-cols-4 (one per service)
- Benefits/features: grid-cols-1 lg:grid-cols-2
- Contact section: Single column centered (max-w-2xl)

## Core Page Structure

### Hero Section
- Full-width with professional imagery (abstract business/technology theme or modern office environment)
- Height: min-h-[600px] lg:min-h-[700px]
- Content centered with max-w-4xl
- Headline + subheadline + primary CTA
- Button on image: backdrop-blur-sm with subtle background

### Services Showcase (4-Column Grid)
Four distinct service cards, each featuring:
- Custom icon from Heroicons
- Service name (bold, prominent)
- 2-3 sentence description
- Hover elevation effect
- Equal height cards with p-8 padding

**Services**:
1. Embudos de Clientes (Sales Funnels)
2. Ventas Automatizadas (Automated Sales)
3. Catálogos Digitales (Digital Catalogs)
4. Páginas Web (Web Development)

### Trust & Social Proof Section
- Client testimonials or success metrics
- 3-column stats display (clients served, projects completed, satisfaction rate)
- Professional badges or certifications if applicable

### Contact Form Section
Full-featured form centered on page (max-w-2xl):
- Form fields: Nombre Completo, Empresa, Email, Teléfono
- Service selection (dropdown or radio buttons)
- Presupuesto Estimado (select ranges)
- Mensaje/Detalles adicionales (textarea)
- Primary submit button
- Trust indicators nearby (response time, security badge)

### Footer
Rich footer with:
- Novalink branding and tagline
- Quick links to services
- Contact information (email, phone)
- Social media links
- Copyright and legal links

## Component Library

**Navigation**:
- Horizontal nav with logo left, links right
- Sticky on scroll
- CTA button in nav (Contactar)
- Mobile: Hamburger menu

**Cards** (Service Cards):
- Rounded corners (rounded-lg or rounded-xl)
- Subtle border
- Padding: p-8
- Hover: translate-y-[-4px] transition
- Icon at top, content stacked vertically

**Buttons**:
- Primary: Large, rounded, bold text
- Secondary: Outlined variant
- Sizes: px-8 py-4 for hero, px-6 py-3 for standard

**Form Elements**:
- Input fields: Full width, rounded-lg, p-4
- Labels: font-medium, mb-2
- Spacing between fields: space-y-6
- Dropdown/Select: Consistent styling with inputs
- Textarea: min-h-[150px]

## Images

**Hero Image**: 
Professional technology/business abstract imagery or modern workspace. Full-width background, subtle overlay for text legibility. Consider: abstract network connections, modern office environment, or digital transformation concept.

**Service Icons**: 
Use Heroicons (outline style) for consistency:
- Funnel icon for Sales Funnels
- Bolt icon for Automated Sales  
- Squares-2x2 icon for Catalogs
- Globe icon for Web Development

**Optional Supporting Images**:
If including a "How It Works" section, use simple illustrated diagrams or abstract geometric backgrounds.

## Accessibility & Performance

- All form inputs with proper labels and ARIA attributes
- Focus states clearly visible on all interactive elements
- Skip to main content link
- Semantic HTML throughout
- Mobile-first responsive breakpoints

## Animations

Minimal, purposeful animations only:
- Subtle fade-in on scroll for sections (optional)
- Hover elevations on cards (transform)
- Smooth scroll to contact form from CTAs
- No complex animations or parallax effects