import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import type { Contact } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Trash2, FileText, ArrowLeft, Pencil } from "lucide-react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { generateContract } from "@/lib/contractGenerator";
import EditContactDialog from "@/components/EditContactDialog";
import { useState } from "react";

export default function Admin() {
  const { toast } = useToast();
  const [editingContact, setEditingContact] = useState<Contact | null>(null);

  const { data: contacts, isLoading } = useQuery<Contact[]>({
    queryKey: ["/api/contacts"],
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await fetch(`/api/contacts/${id}`, {
        method: "DELETE",
      });
      if (!res.ok) throw new Error("Error al eliminar");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/contacts"] });
      toast({
        title: "Contacto eliminado",
        description: "El contacto ha sido eliminado exitosamente.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "No se pudo eliminar el contacto.",
        variant: "destructive",
      });
    },
  });

  const handleGenerateContract = (contact: Contact) => {
    try {
      generateContract(contact);
      toast({
        title: "Contrato generado",
        description: "El PDF del contrato se ha descargado exitosamente.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo generar el contrato.",
        variant: "destructive",
      });
    }
  };

  const getServiceLabel = (serviceType: string) => {
    const services: Record<string, string> = {
      embudos: "Embudos de Clientes",
      automatizacion: "Ventas Automatizadas",
      catalogos: "Catálogos Digitales",
      web: "Páginas Web",
      varios: "Varios Servicios",
    };
    return services[serviceType] || serviceType;
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6 flex items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon" data-testid="button-back-home">
                <ArrowLeft />
              </Button>
            </Link>
            <h1 className="text-3xl font-bold text-foreground">Panel Administrativo</h1>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Contactos Recibidos</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8 text-muted-foreground">Cargando...</div>
            ) : !contacts || contacts.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No hay contactos aún
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Fecha</TableHead>
                      <TableHead>Nombre</TableHead>
                      <TableHead>Empresa</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Teléfono</TableHead>
                      <TableHead>Servicio</TableHead>
                      <TableHead>Presupuesto</TableHead>
                      <TableHead className="text-right">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {contacts.map((contact) => (
                      <TableRow key={contact.id} data-testid={`row-contact-${contact.id}`}>
                        <TableCell className="text-sm text-muted-foreground">
                          {format(new Date(contact.createdAt), "dd/MM/yyyy HH:mm", {
                            locale: es,
                          })}
                        </TableCell>
                        <TableCell className="font-medium">{contact.name}</TableCell>
                        <TableCell>{contact.company}</TableCell>
                        <TableCell>{contact.email}</TableCell>
                        <TableCell>{contact.phone}</TableCell>
                        <TableCell>{getServiceLabel(contact.serviceType)}</TableCell>
                        <TableCell>{contact.budget}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setEditingContact(contact)}
                              data-testid={`button-edit-${contact.id}`}
                            >
                              <Pencil className="w-4 h-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleGenerateContract(contact)}
                              data-testid={`button-generate-contract-${contact.id}`}
                            >
                              <FileText className="w-4 h-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => deleteMutation.mutate(contact.id)}
                              disabled={deleteMutation.isPending}
                              data-testid={`button-delete-${contact.id}`}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        {contacts && contacts.length > 0 && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Detalles de Mensajes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {contacts.map((contact) => (
                  <div
                    key={contact.id}
                    className="border rounded-lg p-4"
                    data-testid={`message-${contact.id}`}
                  >
                    <div className="font-semibold mb-2">
                      {contact.name} ({contact.company})
                    </div>
                    <div className="text-sm text-muted-foreground whitespace-pre-wrap">
                      {contact.message}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {editingContact && (
          <EditContactDialog
            contact={editingContact}
            open={!!editingContact}
            onOpenChange={(open) => !open && setEditingContact(null)}
          />
        )}
      </div>
    </div>
  );
}
