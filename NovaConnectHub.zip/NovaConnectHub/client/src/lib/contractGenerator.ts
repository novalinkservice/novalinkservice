import jsPDF from "jspdf";
import type { Contact } from "@shared/schema";

export function generateContract(contact: Contact) {
  const doc = new jsPDF();
  
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 20;
  let yPos = margin;

  doc.setFontSize(20);
  doc.setFont("helvetica", "bold");
  doc.text("CONTRATO DE SERVICIOS", pageWidth / 2, yPos, { align: "center" });
  yPos += 15;

  doc.setFontSize(16);
  doc.text("Novalink Service", pageWidth / 2, yPos, { align: "center" });
  yPos += 20;

  doc.setFontSize(11);
  doc.setFont("helvetica", "normal");
  
  const addText = (text: string, bold = false) => {
    if (yPos > pageHeight - margin) {
      doc.addPage();
      yPos = margin;
    }
    doc.setFont("helvetica", bold ? "bold" : "normal");
    const lines = doc.splitTextToSize(text, pageWidth - 2 * margin);
    doc.text(lines, margin, yPos);
    yPos += lines.length * 7;
  };

  addText(`Fecha: ${new Date().toLocaleDateString("es-ES")}`, false);
  yPos += 5;

  addText("DATOS DEL CLIENTE", true);
  yPos += 3;
  addText(`Nombre: ${contact.name}`, false);
  addText(`Empresa: ${contact.company}`, false);
  addText(`Email: ${contact.email}`, false);
  addText(`Teléfono: ${contact.phone}`, false);
  yPos += 5;

  addText("SERVICIO CONTRATADO", true);
  yPos += 3;
  
  const serviceLabels: Record<string, string> = {
    embudos: "Embudos de Clientes",
    automatizacion: "Ventas Automatizadas",
    catalogos: "Catálogos Digitales",
    web: "Páginas Web",
    varios: "Varios Servicios",
  };
  
  addText(`Tipo de Servicio: ${serviceLabels[contact.serviceType] || contact.serviceType}`, false);
  addText(`Presupuesto Estimado: ${contact.budget}`, false);
  yPos += 5;

  addText("DETALLES ADICIONALES", true);
  yPos += 3;
  addText(contact.message || "Sin detalles adicionales", false);
  yPos += 10;

  addText("TÉRMINOS Y CONDICIONES", true);
  yPos += 3;
  
  addText("1. El presente contrato establece los términos y condiciones bajo los cuales Novalink Service prestará sus servicios al cliente.", false);
  yPos += 2;
  
  addText("2. Los servicios se entregarán según lo acordado entre ambas partes, con los plazos establecidos en la propuesta comercial.", false);
  yPos += 2;
  
  addText("3. El cliente se compromete a proporcionar toda la información necesaria para la correcta ejecución del proyecto.", false);
  yPos += 2;
  
  addText("4. Los pagos se realizarán según el cronograma acordado en la propuesta comercial.", false);
  yPos += 2;
  
  addText("5. Ambas partes se comprometen a mantener la confidencialidad de la información compartida.", false);
  yPos += 15;

  doc.setFontSize(10);
  doc.text("_________________________", margin + 20, yPos);
  doc.text("_________________________", pageWidth - margin - 70, yPos);
  yPos += 7;
  
  doc.text("Firma del Cliente", margin + 20, yPos, { align: "center" });
  doc.text("Novalink Service", pageWidth - margin - 70, yPos, { align: "center" });
  yPos += 3;
  
  doc.text(contact.name, margin + 20, yPos, { align: "center" });
  doc.text("Representante Legal", pageWidth - margin - 70, yPos, { align: "center" });

  yPos = pageHeight - margin;
  doc.setFontSize(9);
  doc.setTextColor(100);
  doc.text("Novalink Service - novalinkservice@gmail.com - +57 310 228 9521", pageWidth / 2, yPos, { align: "center" });

  const fileName = `Contrato_${contact.company.replace(/\s+/g, "_")}_${Date.now()}.pdf`;
  doc.save(fileName);
}
