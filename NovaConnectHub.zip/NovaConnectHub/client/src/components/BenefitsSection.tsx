import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp, Clock, Users } from "lucide-react";

export default function BenefitsSection() {
  const benefits = [
    {
      icon: TrendingUp,
      title: "Aumenta tus Ventas",
      description: "Estrategias probadas que incrementan tu conversión y ROI de manera medible.",
      testId: "card-beneficio-ventas"
    },
    {
      icon: Clock,
      title: "Ahorra Tiempo",
      description: "Automatización inteligente que te permite enfocarte en lo que realmente importa.",
      testId: "card-beneficio-tiempo"
    },
    {
      icon: Users,
      title: "Conecta con Clientes",
      description: "Herramientas que facilitan la comunicación efectiva con tu audiencia.",
      testId: "card-beneficio-conexion"
    }
  ];

  const stats = [
    { value: "100%", label: "Dedicación", testId: "stat-dedicacion" },
    { value: "24/7", label: "Soporte", testId: "stat-soporte" },
    { value: "Rápido", label: "Tiempo de Respuesta", testId: "stat-respuesta" }
  ];

  return (
    <section id="beneficios" className="py-16 lg:py-24 bg-muted/30">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-5xl font-semibold mb-4 text-foreground">
            ¿Por Qué Novalink?
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Resultados comprobados que transforman negocios
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            return (
              <Card key={index} className="hover-elevate transition-all duration-300" data-testid={benefit.testId}>
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 mx-auto mb-6 flex items-center justify-center rounded-lg bg-primary/10">
                    <Icon className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="text-2xl font-semibold mb-3 text-foreground">{benefit.title}</h3>
                  <p className="text-base text-muted-foreground">{benefit.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center" data-testid={stat.testId}>
              <div className="text-5xl lg:text-6xl font-bold text-primary mb-2">{stat.value}</div>
              <div className="text-lg text-muted-foreground">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
