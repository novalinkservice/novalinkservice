import { Button } from "@/components/ui/button";
import heroImage from "@assets/generated_images/Hero_background_technology_network_c3be2e03.png";

export default function HeroSection() {
  const scrollToContact = () => {
    const element = document.getElementById('contacto');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative min-h-[600px] lg:min-h-[700px] flex items-center justify-center overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroImage})` }}
      />
      <div className="absolute inset-0 bg-gradient-to-br from-background/95 via-background/85 to-background/75" />
      
      <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
        <h1 className="text-5xl lg:text-7xl font-bold mb-6 text-foreground">
          Conectamos Empresas con sus Clientes
        </h1>
        <p className="text-lg lg:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
          Transformamos tu negocio con soluciones digitales efectivas: embudos de ventas, automatización, catálogos digitales y páginas web que generan resultados.
        </p>
        <Button
          size="lg"
          onClick={scrollToContact}
          className="px-8 py-6 text-lg"
          data-testid="button-hero-cta"
        >
          Comenzar Ahora
        </Button>
      </div>
    </section>
  );
}
