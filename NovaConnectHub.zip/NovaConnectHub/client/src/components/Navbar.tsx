import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Menu } from "lucide-react";
import { useState } from "react";

export default function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setMobileMenuOpen(false);
    }
  };

  return (
    <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between gap-4">
          <Link href="/">
            <span className="text-2xl font-bold text-primary hover-elevate active-elevate-2 rounded-md px-3 py-2 cursor-pointer" data-testid="link-home">
              Novalink<span className="text-xs font-normal ml-1">Service</span>
            </span>
          </Link>

          <div className="hidden md:flex items-center gap-2">
            <Button
              variant="ghost"
              onClick={() => scrollToSection('servicios')}
              data-testid="button-nav-servicios"
            >
              Servicios
            </Button>
            <Button
              variant="ghost"
              onClick={() => scrollToSection('beneficios')}
              data-testid="button-nav-beneficios"
            >
              Beneficios
            </Button>
            <Button
              onClick={() => scrollToSection('contacto')}
              data-testid="button-nav-contacto"
            >
              Contactar
            </Button>
          </div>

          <Button
            size="icon"
            variant="ghost"
            className="md:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            data-testid="button-mobile-menu"
          >
            <Menu />
          </Button>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden mt-4 flex flex-col gap-2">
            <Button
              variant="ghost"
              onClick={() => scrollToSection('servicios')}
              data-testid="button-mobile-servicios"
            >
              Servicios
            </Button>
            <Button
              variant="ghost"
              onClick={() => scrollToSection('beneficios')}
              data-testid="button-mobile-beneficios"
            >
              Beneficios
            </Button>
            <Button
              onClick={() => scrollToSection('contacto')}
              data-testid="button-mobile-contacto"
            >
              Contactar
            </Button>
          </div>
        )}
      </div>
    </nav>
  );
}
