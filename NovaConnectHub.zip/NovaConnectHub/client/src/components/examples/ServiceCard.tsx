import ServiceCard from '../ServiceCard';
import funnelIcon from '@assets/generated_images/Sales_funnel_icon_illustration_87c9217f.png';

export default function ServiceCardExample() {
  return (
    <ServiceCard
      icon={funnelIcon}
      title="Embudos de Clientes"
      description="Diseñamos estrategias personalizadas para convertir visitantes en clientes leales y aumentar tus ventas."
    />
  );
}
