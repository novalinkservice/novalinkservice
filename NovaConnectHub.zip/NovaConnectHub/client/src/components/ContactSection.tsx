import ContactForm from "./ContactForm";
import { Shield, Clock } from "lucide-react";

export default function ContactSection() {
  return (
    <section id="contacto" className="py-16 lg:py-24 bg-background">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-5xl font-semibold mb-4 text-foreground">
            Comienza Tu Proyecto
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
            Completa el formulario y nos pondremos en contacto contigo en menos de 24 horas
          </p>
          
          <div className="flex items-center justify-center gap-8 mb-12">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Clock className="w-5 h-5 text-primary" />
              <span>Respuesta en 24h</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Shield className="w-5 h-5 text-primary" />
              <span>Información Segura</span>
            </div>
          </div>
        </div>

        <ContactForm />
      </div>
    </section>
  );
}
