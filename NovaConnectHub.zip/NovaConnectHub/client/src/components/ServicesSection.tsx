import ServiceCard from "./ServiceCard";
import funnelIcon from "@assets/generated_images/Sales_funnel_icon_illustration_87c9217f.png";
import automationIcon from "@assets/generated_images/Automation_icon_illustration_d4af7517.png";
import catalogIcon from "@assets/generated_images/Digital_catalog_icon_illustration_ea1de0fe.png";
import webIcon from "@assets/generated_images/Web_development_icon_illustration_3d9ac8a4.png";

export default function ServicesSection() {
  const services = [
    {
      icon: funnelIcon,
      title: "Embudos de Clientes",
      description: "Diseñamos estrategias personalizadas para convertir visitantes en clientes leales y aumentar tus ventas.",
      testId: "card-servicio-embudos"
    },
    {
      icon: automationIcon,
      title: "Ventas Automatizadas",
      description: "Implementamos sistemas inteligentes que venden por ti las 24 horas, optimizando tu proceso de ventas.",
      testId: "card-servicio-automatizacion"
    },
    {
      icon: catalogIcon,
      title: "Catálogos Digitales",
      description: "Creamos catálogos interactivos y atractivos que presentan tus productos de manera profesional.",
      testId: "card-servicio-catalogos"
    },
    {
      icon: webIcon,
      title: "Páginas Web",
      description: "Desarrollamos sitios web modernos, rápidos y optimizados que reflejan la esencia de tu negocio.",
      testId: "card-servicio-web"
    }
  ];

  return (
    <section id="servicios" className="py-16 lg:py-24 bg-background">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-5xl font-semibold mb-4 text-foreground">
            Nuestros Servicios
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Soluciones digitales completas diseñadas para impulsar tu negocio al siguiente nivel
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <ServiceCard key={index} {...service} />
          ))}
        </div>
      </div>
    </section>
  );
}
