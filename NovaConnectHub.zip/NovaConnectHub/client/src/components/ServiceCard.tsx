import { Card, CardContent } from "@/components/ui/card";

interface ServiceCardProps {
  icon: string;
  title: string;
  description: string;
  testId?: string;
}

export default function ServiceCard({ icon, title, description, testId }: ServiceCardProps) {
  return (
    <Card className="hover-elevate transition-all duration-300" data-testid={testId}>
      <CardContent className="p-8 flex flex-col items-center text-center h-full">
        <div className="w-24 h-24 mb-6 flex items-center justify-center">
          <img src={icon} alt={title} className="w-full h-full object-contain" />
        </div>
        <h3 className="text-2xl font-semibold mb-4 text-foreground">{title}</h3>
        <p className="text-base text-muted-foreground leading-relaxed">{description}</p>
      </CardContent>
    </Card>
  );
}
